package com.example.pracc_main

import android.app.AlertDialog
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private var namesList= mutableListOf("Ramos", "Maldini")
    private var picsInt= mutableListOf(R.drawable.ramos, R.drawable.maldini)
    private lateinit var adapter: PlayerAdapter

    private val availablePlayers= intArrayOf(R.drawable.ramos, R.drawable.maldini, R.drawable.ozil, R.drawable.zidane, R.drawable.modric, R.drawable.salah, R.drawable.ronaldinho, R.drawable.mbappe, R.drawable.neymar2, R.drawable.henry, R.drawable.beckham, R.drawable.kaka2, R.drawable.lionel_messi, R.drawable.cristiano_ronaldo)
    private val availablePlayerNames= arrayOf("Ramos", "Maldini", "Ozil", "Zidane", "Modric", "Salah", "Ronaldinho", "Mbappe", "Neymar", "Henry", "Beckham", "Kaka", "Messi", "Ronaldo")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        listView= findViewById(R.id.lv)
    }

    private fun setupListeners(){
        adapter= PlayerAdapter()
        listView.adapter= adapter
        registerForContextMenu(listView)
    }

    inner class PlayerAdapter: BaseAdapter(){
        override fun getCount(): Int= namesList.size
        override fun getItem(position: Int): Any= namesList[position]
        override fun getItemId(position: Int): Long= position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View = convertView?: layoutInflater.inflate(R.layout.row_view, parent, false)

            val playerPicture: ImageView = view.findViewById(R.id.ivPicture)
            val playerName: TextView= view.findViewById(R.id.tvName)

            playerPicture.setImageResource(picsInt[position])
            playerName.text = namesList[position]

            return view
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.opt_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.opt_New ->{
                showPlayerDialog(-1)
                return true
            }

            R.id.optReset ->{
                resetToDefault()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        menuInflater.inflate(R.menu.ctx_menu, menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val position = info.position

        return when(item.itemId){
            R.id.ctxModify ->{
                showPlayerDialog(position)
                true
            }
             R.id.ctxDelete ->{
                 deletePlayer(position)
                 true
             }
            R.id.ctxNew ->{
                showPlayerDialog(-1)
                true
            }

            else -> super.onContextItemSelected(item)
        }
    }

    private fun showPlayerDialog(position: Int){
        val dialogView= layoutInflater.inflate(R.layout.dialog_player, null)
        val edtDialogPlayeName= dialogView.findViewById<EditText>(R.id.edtDialogPlayerName)
        val ivDialogPlayerPicture= dialogView.findViewById<ImageView>(R.id.ivDialogPlayerPicture)
        val gridViewPlayers= dialogView.findViewById<GridView>(R.id.gridViewPlayers)

        var selectedImagesRes= if(position>=0) picsInt[position] else availablePlayers[0]

        if(position >= 0){
            edtDialogPlayeName.setText(namesList[position])
            ivDialogPlayerPicture.setImageResource(picsInt[position])
        }
        else{
            ivDialogPlayerPicture.setImageResource(availablePlayers[0])
        }

        val gridAdapter= object: BaseAdapter(){
            override fun getCount(): Int = availablePlayers.size
            override fun getItem(position: Int): Any = availablePlayers[position]
            override fun getItemId(position: Int): Long= position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View{
                val imageView: ImageView = if(convertView==null){
                    ImageView(this@MainActivity).apply {
                        layoutParams= ViewGroup.LayoutParams(150,150)
                        scaleType = ImageView.ScaleType.CENTER_CROP
                    }
                }
                else{
                    convertView as ImageView
                }

                imageView.setImageResource(availablePlayers[position])
                return imageView

            }
        }
        gridViewPlayers.adapter= gridAdapter

        gridViewPlayers.onItemClickListener= AdapterView.OnItemClickListener{_,_,positionGrid,_ ->
            selectedImagesRes= availablePlayers[positionGrid]
            ivDialogPlayerPicture.setImageResource(selectedImagesRes)
        }

        val dialog= AlertDialog.Builder(this)
            .setTitle(if(position>=0) "Modify Player" else "Add New Player")
            .setView(dialogView)
            .setPositiveButton("Save"){_,_ ->
                val name= edtDialogPlayeName.text.toString().trim()
                if(name.isNotEmpty()){
                    if(position>=0){
                        namesList[position]= name
                        picsInt[position]= selectedImagesRes
                        Toast.makeText(this,"Player Modified", Toast.LENGTH_SHORT).show()
                    }
                    else{
                        namesList.add(name)
                        picsInt.add(selectedImagesRes)
                        Toast.makeText(this, "New Player Added", Toast.LENGTH_SHORT).show()
                    }
                    adapter.notifyDataSetChanged()
                }
                else{
                    Toast.makeText(this, "Please enter a player name", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }

    private fun deletePlayer(position: Int){
        val playerName= namesList[position]

        AlertDialog.Builder(this)
            .setTitle("Delete Player")
            .setMessage("Are you sure you want to delete $playerName?")
            .setPositiveButton("Delete"){_,_ ->
                namesList.removeAt(position)
                picsInt.removeAt(position)
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Player Deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()

    }

    private fun resetToDefault(){
        namesList.clear()
        picsInt.clear()

        namesList.add("Ramos")
        namesList.add("Maldini")
        picsInt.add(R.drawable.ramos)
        picsInt.add(R.drawable.maldini)

        adapter.notifyDataSetChanged()
        Toast.makeText(this, "Reset to default players!", Toast.LENGTH_SHORT).show()
    }
}