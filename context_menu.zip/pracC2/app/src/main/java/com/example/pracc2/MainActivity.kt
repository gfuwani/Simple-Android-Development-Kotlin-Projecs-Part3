package com.example.pracc2

import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val dataList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
        initializeData()
    }

    private fun initializeViews(){
        listView=findViewById(R.id.lv)
        adapter= ArrayAdapter(this,android.R.layout.simple_list_item_1,dataList)
        listView.adapter= adapter
    }

    private fun setupListeners(){
        registerForContextMenu(listView)
    }

    private fun initializeData(){
        for(i in 0..9){
            dataList.add("Item $i")
        }
        adapter.notifyDataSetChanged()
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        menuInflater.inflate(R.menu.ctx_menu,menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info= item.menuInfo as android.widget.AdapterView.AdapterContextMenuInfo
        val position= info.position

        return when(item.itemId){
            R.id.insert->{
                val randomNumber= Random.nextInt(100)
                dataList.add(position, "Random Item $randomNumber")
                adapter.notifyDataSetChanged()
                true
            }

            R.id.delete->{
                dataList.removeAt(position)
                adapter.notifyDataSetChanged()
                true
            }
            else-> super.onContextItemSelected(item)
        }
    }
}