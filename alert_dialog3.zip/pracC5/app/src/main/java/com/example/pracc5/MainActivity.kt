package com.example.pracc5

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var tvShow: TextView
    private lateinit var btEnter: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        tvShow= findViewById(R.id.tvShow)
        btEnter= findViewById(R.id.btEnter)

    }

    private fun setupListeners(){
        btEnter.setOnClickListener {
            val dialogView= layoutInflater.inflate(R.layout.dialog_view, null)

            val dialogcbRunning= dialogView.findViewById<CheckBox>(R.id.cbRunning)
            val dialogcbSwimming= dialogView.findViewById<CheckBox>(R.id.cbSwimming)
            val dialogcbBasketball= dialogView.findViewById<CheckBox>(R.id.cbBasketball)

           dialogcbRunning.setOnCheckedChangeListener { buttonView, isChecked ->
               if(dialogcbRunning.isChecked){
                   dialogcbSwimming.isChecked= false
                   dialogcbBasketball.isChecked= false
               }
           }

            dialogcbSwimming.setOnCheckedChangeListener { buttonView, isChecked ->
                if(dialogcbSwimming.isChecked){
                    dialogcbRunning.isChecked= false
                    dialogcbBasketball.isChecked= false
                }
            }

            dialogcbBasketball.setOnCheckedChangeListener { buttonView, isChecked ->
                if(dialogcbBasketball.isChecked){
                    dialogcbRunning.isChecked= false
                    dialogcbSwimming.isChecked= false
                }
            }

            val alertDialog = AlertDialog.Builder(this)
                .setTitle("Activities")
                .setView(dialogView)
                .setPositiveButton("OK"){dialog, which ->
                    when{
                        dialogcbRunning.isChecked -> tvShow.text= dialogcbRunning.text
                        dialogcbSwimming.isChecked -> tvShow.text= dialogcbSwimming.text
                        dialogcbBasketball.isChecked -> tvShow.text= dialogcbBasketball.text

                        else -> tvShow.text= "No activity selected"
                    }
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel"){dialog, which ->
                    tvShow.text= ""
                    dialog.dismiss()
                }
                .create()
            alertDialog.show()
        }
    }
}