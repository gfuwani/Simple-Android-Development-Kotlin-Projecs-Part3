package com.example.pracc4

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var tvShow: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        tvShow= findViewById(R.id.tvShow)
    }

    private fun setupListeners(){
        tvShow.setOnLongClickListener {
            val dialogView= layoutInflater.inflate(R.layout.dialog_view,null)
            val edtShow= dialogView.findViewById<EditText>(R.id.edtShow)

            edtShow.setText(tvShow.text)

            val alertDialog= AlertDialog.Builder(this)
                .setTitle("Student Information")
                .setView(dialogView)
                .setPositiveButton("OK"){dialog,_->
                    val newText= edtShow.text.toString()
                    tvShow.text= newText
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel"){dialog,_ ->
                    dialog.dismiss()
                }
                .create()

            alertDialog.show()
            true
        }
    }

}